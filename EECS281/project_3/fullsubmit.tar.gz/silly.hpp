// Project Identifier: C0F4DFE8B340D81183C208F70F9D2D797908754D
//  silly.hpp
//  project_3
//
//  Created by Ellen Chlachidze on 10/30/22.
//

#ifndef silly_hpp
#define silly_hpp

#include <stdio.h>

#endif /* silly_hpp */
